#!/usr/bin/env node
'use strict';

// 重大虎溪校园助手 · 辅助脚本（随 WorkBuddy 技能分发，只用 Node.js 自带模块）。
// 数据在同目录的 campus-data.json，由项目里的 tools/build-skill.cjs 从网页小助手的同一份资料生成。
//   node campus.cjs week [YYYY-MM-DD]          第几周、教学/考试/假期、当天的校历事项
//   node campus.cjs room <教室代码>             校区、楼栋、楼层、地图位置与导航链接
//   node campus.cjs day <课表文件> [YYYY-MM-DD]  那天的课程（支持小助手导出的 .ics 与备份 .json）
//   node campus.cjs find <关键词>               相关资料条目与文件路径
// 不写日期时按北京时间的今天计算。
const fs = require('node:fs');
const path = require('node:path');

const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'campus-data.json'), 'utf8'));
const DAY_NAMES = ['一', '二', '三', '四', '五', '六', '日'];

function beijingToday() {
  const now = new Date(Date.now() + 8 * 3600 * 1000);
  return now.toISOString().slice(0, 10);
}

function ordinal(key) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(key || ''));
  if (!match) return null;
  const time = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  const check = new Date(time);
  if (check.getUTCMonth() !== Number(match[2]) - 1) return null;
  return time / 86400000;
}

function weekdayOf(key) {
  const day = new Date(ordinal(key) * 86400000).getUTCDay();
  return day === 0 ? 7 : day;
}

function dayInfo(key) {
  const day = ordinal(key);
  if (day === null) throw new Error('日期请写成 YYYY-MM-DD，例如 2026-11-18');
  const term = data.terms.find(item => key >= item.startDate && key <= item.endDate) || null;
  const week = term ? Math.floor((day - ordinal(term.startDate)) / 7) + 1 : null;
  const inRange = item => key >= item.start && key <= item.end;
  return {
    key,
    weekday: weekdayOf(key),
    term,
    week,
    period: term ? term.periods.find(inRange) || null : null,
    events: term ? term.events.filter(inRange) : []
  };
}

function slotTimes(term) {
  const map = {};
  (term ? term.timeSlots : []).forEach(slot => {
    const match = /第\s*(\d+)\s*节/.exec(slot.lesson || '');
    if (match) map[Number(match[1])] = slot;
  });
  return map;
}

function parseRoom(value) {
  const text = String(value || '')
    .replace(/\s+/g, '')
    .toUpperCase();
  const codes = data.rooms
    .map(room => room.buildingCode)
    .sort((a, b) => b.length - a.length)
    .map(code => code.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const match = new RegExp('([DAB])(' + codes.join('|') + ')(\\d{3,4})(?!\\d)').exec(text);
  if (!match) return null;
  const room = data.rooms.find(
    item => item.campusCode === match[1] && item.buildingCode.toUpperCase() === match[2]
  );
  if (!room) return null;
  const building = room.buildingId ? data.buildings.find(item => item.id === room.buildingId) : null;
  return {
    code: match[1] + match[2] + match[3],
    campus: room.campus,
    building: room.building,
    floor: match[3].length === 3 ? Number(match[3][0]) || null : null,
    mapTitle: room.mapTitle || '',
    coordinates: building ? building.gcj02 : null,
    links: building ? building.links : [],
    address: room.address || null
  };
}

function describeRoom(room, withNote) {
  return (
    room.campus +
    ' · ' +
    room.building +
    (room.floor ? ' · ' + room.floor + ' 楼' : '') +
    (withNote && !room.links.length
      ? room.address
        ? '（没有精确坐标，可按门牌地址搜索）'
        : '（楼栋坐标未收录，不提供导航）'
      : '')
  );
}

function weekCommand(key) {
  const info = dayInfo(key);
  const lines = [`${key}（星期${DAY_NAMES[info.weekday - 1]}）`];
  if (!info.term) {
    const recorded = data.terms.map(term => `${term.title}（${term.startDate}—${term.endDate}）`);
    lines.push('这一天不在已收录的校历范围内，不推算周次。已收录：' + recorded.join('；'));
    return lines.join('\n');
  }
  lines.push(`${info.term.title} · 第 ${info.week} 周`);
  if (info.period) lines.push(`阶段：${info.period.title}（${info.period.start}—${info.period.end}）`);
  info.events.forEach(event => lines.push(`校历事项：${event.title}${event.summary ? ' · ' + event.summary : ''}`));
  return lines.join('\n');
}

function roomCommand(code) {
  const room = parseRoom(code);
  if (!room) return `没有在教室代码表里找到「${code}」。请对照资料《课表教室代码怎么读》。`;
  const lines = [`${room.code}：${describeRoom(room, true)}`];
  if (room.mapTitle) lines.push(`小助手地图上的位置：${room.mapTitle}`);
  if (room.coordinates) lines.push(`坐标（GCJ-02）：${room.coordinates.lat}, ${room.coordinates.lng}`);
  room.links.forEach(link => lines.push(`${link.label}：${link.href}`));
  if (!room.links.length && room.address) {
    lines.push(`门牌地址：${room.address.text}（${room.address.city}）· ${room.address.source}`);
    room.address.links.forEach(link =>
      lines.push(`${link.label}（按地址搜索，落点以地图应用为准）：${link.href}`)
    );
  }
  return lines.join('\n');
}

// .ics：小助手每次课导出一个 VEVENT，DTSTART;TZID=Asia/Shanghai:YYYYMMDDTHHMMSS。
function coursesFromIcs(text, key) {
  const unfolded = text.replace(/\r?\n[ \t]/g, '');
  const compact = key.replace(/-/g, '');
  const events = [];
  unfolded.split(/BEGIN:VEVENT/).slice(1).forEach(block => {
    const field = name => {
      const match = new RegExp('^' + name + '(?:;[^:\\n]*)?:(.*)$', 'm').exec(block);
      return match
        ? match[1]
            .trim()
            .replace(/\\n/g, ' ')
            .replace(/\\([,;\\])/g, '$1')
        : '';
    };
    const start = field('DTSTART');
    if (!start.startsWith(compact)) return;
    const end = field('DTEND');
    const time = value => (value.length >= 13 ? value.slice(9, 11) + ':' + value.slice(11, 13) : '');
    events.push({ start: time(start), end: time(end), name: field('SUMMARY'), room: field('LOCATION'), teacher: '' });
  });
  return events.sort((a, b) => a.start.localeCompare(b.start));
}

// 备份 JSON：data.timetable.courses + adjustments；也接受直接导出的 timetable 对象。
function coursesFromBackup(json, info) {
  const timetable = json && json.data && json.data.timetable ? json.data.timetable : json;
  if (!timetable || !Array.isArray(timetable.courses)) throw new Error('这个 JSON 里没有找到课表（data.timetable.courses）');
  if (!info.term || !info.week) return { note: '这一天不在已收录的校历范围内，无法确定周次。', list: [] };
  const adjustment = (timetable.adjustments || []).find(
    item => item.date === info.key && (!item.termId || item.termId === info.term.id)
  );
  if (adjustment && adjustment.kind === 'cancel')
    return { note: '这一天停课' + (adjustment.note ? '：' + adjustment.note : '') + '。', list: [] };
  const day = adjustment && adjustment.kind === 'swap' ? adjustment.day : info.weekday;
  const slots = slotTimes(info.term);
  const list = timetable.courses
    .filter(course => !course.termId || course.termId === info.term.id)
    .filter(course => course.day === day && Array.isArray(course.weeks) && course.weeks.includes(info.week))
    .sort((a, b) => a.start - b.start)
    .map(course => ({
      lessons: course.start === course.end ? `第 ${course.start} 节` : `第 ${course.start}–${course.end} 节`,
      start: slots[course.start] ? slots[course.start].start : '',
      end: slots[course.end] ? slots[course.end].end : '',
      name: course.name,
      room: course.room || '',
      teacher: course.teacher || ''
    }));
  const note = adjustment && adjustment.kind === 'swap' ? `这一天按星期${DAY_NAMES[day - 1]}的课表上课。` : '';
  return { note, list };
}

function dayCommand(file, key) {
  const text = fs.readFileSync(file, 'utf8').replace(/^﻿/, '');
  const info = dayInfo(key);
  const header = `${key}（星期${DAY_NAMES[info.weekday - 1]}${info.week ? ' · 第 ' + info.week + ' 周' : ''}）`;
  let result;
  if (/BEGIN:VCALENDAR/.test(text)) result = { note: '', list: coursesFromIcs(text, key) };
  else result = coursesFromBackup(JSON.parse(text), info);
  const lines = [header];
  if (result.note) lines.push(result.note);
  if (!result.list.length) {
    if (!result.note) lines.push('这一天没有课。');
    return lines.join('\n');
  }
  result.list.forEach(course => {
    const room = course.room ? parseRoom(course.room) : null;
    const where = course.room ? course.room + (room ? '（' + describeRoom(room) + '）' : '') : '地点未填';
    lines.push(
      [course.lessons, course.start && course.end ? course.start + '–' + course.end : '', course.name, where, course.teacher]
        .filter(Boolean)
        .join(' · ')
    );
  });
  return lines.join('\n');
}

function findCommand(words) {
  const query = words.join(' ').toLowerCase().trim();
  if (!query) return '请提供关键词，例如：node campus.cjs find 校园网';
  const terms = query.split(/\s+/);
  const scored = data.entries
    .map(entry => {
      const title = entry.title.toLowerCase();
      const keywords = entry.keywords.map(word => word.toLowerCase());
      let score = 0;
      terms.forEach(term => {
        if (title.includes(term)) score += 3;
        if (keywords.some(word => word.includes(term) || term.includes(word))) score += 2;
        if (entry.category.toLowerCase().includes(term)) score += 1;
      });
      return { entry, score };
    })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score || a.entry.title.localeCompare(b.entry.title, 'zh-CN'))
    .slice(0, 10);
  if (!scored.length) return `没有找到和「${query}」相关的条目。可以换个说法，或打开 references/index.md 查看全部目录。`;
  return scored.map(item => `《${item.entry.title}》 ${item.entry.file}`).join('\n');
}

function main(args) {
  const [command, ...rest] = args;
  if (command === 'week') return weekCommand(rest[0] || beijingToday());
  if (command === 'room') return roomCommand(rest.join(''));
  if (command === 'day') {
    if (!rest[0]) throw new Error('请提供课表文件路径：node campus.cjs day 课表.json [YYYY-MM-DD]');
    return dayCommand(rest[0], rest[1] || beijingToday());
  }
  if (command === 'find') return findCommand(rest);
  return [
    '用法：',
    '  node campus.cjs week [YYYY-MM-DD]',
    '  node campus.cjs room <教室代码>',
    '  node campus.cjs day <课表文件(.ics/.json)> [YYYY-MM-DD]',
    '  node campus.cjs find <关键词>'
  ].join('\n');
}

if (require.main === module) {
  try {
    console.log(main(process.argv.slice(2)));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

module.exports = { main, parseRoom, dayInfo };
